clear variables;
close all;

Img=imread('vlcsnap-2019-01-11-14h20m35s71.jpg');
imwrite(Img,'image.ppm');
figure(1)
imshow('image.ppm')

for i=1:1:3
    figure(2)
    subplot(2,3,i)
    imshow(Img(:,:,i));
end


subplot(234)
rouge=Img;
rouge(:,:,[2:3])=0;
imshow(rouge)
subplot(235)
vert=Img;
vert(:,:,[1,3])=0;
imshow(vert)
subplot(236)
bleu=Img;
bleu(:,:,[1:2])=0;
imshow(bleu)



Mat=[[1,0,1.13983];[1,-0.39465,-0.58060];[1,2.03211,0]];
Matinv=Mat^(-1);

hsv=rgb2hsv(Img(:,:,[1:3]));

for i=1:1:3
    figure(3)
    subplot(1,3,i)
    imshow(hsv(:,:,i));
end

    

