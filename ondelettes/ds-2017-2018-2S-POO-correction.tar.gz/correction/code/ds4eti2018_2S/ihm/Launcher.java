package ds4eti2018_2S.ihm;

public class Launcher {
	
	public static void main(String [] a){
		new Fenetre();
	}

}
