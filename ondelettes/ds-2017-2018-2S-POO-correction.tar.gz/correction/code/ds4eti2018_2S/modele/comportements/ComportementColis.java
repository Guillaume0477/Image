package ds4eti2018_2S.modele.comportements;

public interface ComportementColis {
	public double getPrix(int km);
	public int getDelai();

}
