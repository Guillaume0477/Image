
clear variables;
close all;

% fichiers images
tab_images={'1.tif','2.tif','3.tif','4.tif','5.tif','6.tif'};
m=length(tab_images);

% taille des image
tmp=imread(char(tab_images(1)));
[H,W]=size(tmp);

% matrice de m images
I=zeros(H,W,m);

% affichage des images satellitaires
for k=1:m
    I(:,:,k)=im2double(imread(char(tab_images(k))));
    subplot(2,3,k);
    imshow(I(:,:,k));
end

% matrice des donn�es
% r�-arrangement dans une matrice de n=H*W lignes et 6 colonnes
n=H*W;