clear all; close all;

n=10; type='gaussian'; std=0.8; supp=9;
H = matH_1D(n,supp,type,std);